import boto3
from botocore.exceptions import ClientError
from boto3.exceptions import S3UploadFailedError
import argparse
import os.path
import threading
import sys
from pathlib import Path

try:
    from importlib import metadata
except ImportError:  # for Python<3.8
    import importlib_metadata as metadata
__version__ = metadata.version("armory-upload")


# this AWS key prefix need to be changed once per evaluation period
evaluation_period = "eval7"
bucket = "armory-submission-data"

file_types = "config dockerfile docker-image model-weights".split()


class ProgressPercentage(object):
    def __init__(self, filename):
        self._filename = filename
        self._size = os.path.getsize(filename)
        self._seen_so_far = 0
        self._lock = threading.Lock()

    def __call__(self, bytes_amount):
        # To simplify, assume this is hooked up to a single filename
        with self._lock:
            self._seen_so_far += bytes_amount
            percentage = (self._seen_so_far / float(self._size)) * 100
            sys.stdout.write(
                f"\r{self._filename} {self._seen_so_far:,} bytes / {self._size:,} {percentage:.2f}%"
            )
            sys.stdout.flush()


def upload_one(code, submitter, file_type, file) -> str:
    # this violates the maxim: don't check credentials into git
    # to minimize bad actions, this IAM user only allows PutObject for specific keys in the bucket
    # and no other permisisons at all. TwoSix reviewers can confirm that AWS user/armory-uploader
    # has permissions as stated and matches the access_key_id
    s3 = boto3.client(
        "s3",
        aws_access_key_id="AKIA3RW3FNVFV2N7OEJX",
        aws_secret_access_key="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",
    )

    path = Path(file)
    target = path.name
    if code not in target:
        target = f"{code}-{target}"
        print(f"performer code {code} prepended to {target} for upload")
    key = f"{evaluation_period}/{code}/{submitter}/{file_type}/{target}"

    try:
        s3.upload_file(str(file), bucket, key, Callback=ProgressPercentage(file))
    except (ClientError, S3UploadFailedError):
        print(
            f"Failed to upload {path} to {key}\n"
            f"Check that {code} is your registered performer code "
            f"and that {path} is a readable file.\n\n"
            "If this error persists, please send the following traceback to armory@twosixtech.com\n\n",
            file=sys.stderr,
        )
        raise S3UploadFailedError(f"failed to upload {path} to {key}") from None

    return key


def main():
    print(f"armory-upload version {__version__}")
    parser = argparse.ArgumentParser(
        prog="armory-upload", description=f"Upload a GARD submission file to S3"
    )
    parser.add_argument("CODE", help="performer code")
    parser.add_argument("submitter", help="submitter email address")
    parser.add_argument("file_type", help="file type, one of: " + ", ".join(file_types))
    parser.add_argument("file", help="file to upload")

    args = parser.parse_args()
    code, submitter, file_type, file = (
        args.CODE,
        args.submitter,
        args.file_type,
        args.file,
    )
    if file_type not in file_types:
        print(
            f"unknown file type {file_type}, must be one of {file_types}",
            file=sys.stderr,
        )
        sys.exit(1)
    if "@" not in submitter:
        print(
            f"please check that {submitter} is a valid email address", file=sys.stderr
        )
        sys.exit(1)

    key = upload_one(code, submitter, file_type, file)
    print(f"\nuploaded {file} to {key}")


if __name__ == "__main__":
    main()
